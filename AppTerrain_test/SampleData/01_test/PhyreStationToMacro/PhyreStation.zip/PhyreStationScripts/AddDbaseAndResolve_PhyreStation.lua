--[[ 
--   Description
--   -----------
--   Close a previously open workspace if one exists. Then proceeds to open a existing Workspace project file.
--   The project file contains references to two databases and resolves the links in both
--
--   PhyreStation v2.1.0
--]]

--  Close any existing working workspaces in the appplication
--  (Also closes the Script Manager Dialog if open)
--
result = CloseWorkspace() 

--
-- Create a totally new workspace
--
result = NewWorkspace( "NewWorkspace" )
if result > 0 then
	print( "New Workspace command failed" )
end

--
-- Lets add an exisiting database to the current workspace
--
result, dbId = AddDatabase( os.getenv( "SCE_PSSG" ) .. "/Scenes/Monkee", "monkee.PSSG" )
if result > 0 then
	print( "Add Database command failed" )
end

--
-- Now resolve the just loaded database to make sure it is complete
--
result = ResolveLinks( dbId )
if result > 0 then
	print( "ResolveLinks command failed" )
end

--
-- Retrieve the nickname used for a camera object in the database monkee.PSSG
--
result, name = GetObjectProperty( "monkee.PSSG#/front", "Nickname", 0 )
if result == 0 then
	print( "Nickname is " .. name )
else
	print( "GetObjectProperty command failed" )
end

--
-- Change the nickname used for a camera object in the database monkee.PSSG
--
result = SetObjectProperty( "monkee.PSSG#/front", "Nickname", 0, "iDave" )
if result > 0 then
	print( "SetObjectProperty command failed" )
end

--
-- Retrieve the nickname used for a camera object in the database monkee.PSSG
--
result, name = GetObjectProperty( "monkee.PSSG#/front", "Nickname", 0 )
if result == 0 then
	print( "Nickname is " .. name )
else
	print( "GetObjectProperty command failed" )
end