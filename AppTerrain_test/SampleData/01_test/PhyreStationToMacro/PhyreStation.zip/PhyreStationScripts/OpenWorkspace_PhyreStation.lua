--[[ 
--   Description
--   -----------
--   Close a previously open workspace if one exists. Then proceeds to open a existing Workspace project file.
--   The project file contains references to two databases and resolves the links in one.
--
--   PhyreStation v2.1.0
--]]

--  Close any existing working workspaces in the appplication
--  (Also closes the Script Manager Dialog if open)
--
result = CloseWorkspace() 

--
-- Open an existing workspace project file
--
print("Opened Workspace" );  
result = OpenWorkspace( os.getenv( "SCE_PSSG" ) .. "/Tools/PhyreStation/PhyreStationWorkspaces", "MyFirstWorkspace_PhyreStation.xml" )
if result > 0 then
	print( "Open Workspace command failed" )
end

print("Resolve the 'houseLit.PSSG' database")
result = ResolveLinks( "houseLit.PSSG" );
if result > 0 then
	print( "ResolveLinks Workspace command failed" )
end
