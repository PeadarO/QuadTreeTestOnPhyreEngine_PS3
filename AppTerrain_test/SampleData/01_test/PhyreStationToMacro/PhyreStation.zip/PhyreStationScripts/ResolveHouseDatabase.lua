--[[ 
--   Description
--   -----------
--   Resolves the links of a database that already exsits in the workspace.
--   Demonstrates how script-files can be referenced from workspace files.
--
--   PhyreStation v2.1.0
--]]

-- This script-file is referenced from MyFirstWorkspace.xml, and demonstrates
-- how scripts can be managed from workspaces. This script assumes a database
-- called 'houseLit.PSSG' exists: 'houseLit.PSSG' is created by 
-- MyFirstWorkspace_PhyreStation.xml.
--
-- NB. This script is not intended to be run separately from 
-- MyFirstWorkspace_PhyreStation.xml.

result = 0		-- 0 = function success, > 0 = error code
print("Resolving links for database 'houseLit.PSSG'..." );  
result = ResolveLinks( "houseLit.PSSG" ) 
if result > 0 then
	print( "Failed to resolved links for 'houseLit.PSSG'." )
else
	print( "Resolved links for 'houseLit.PSSG'." )
end
