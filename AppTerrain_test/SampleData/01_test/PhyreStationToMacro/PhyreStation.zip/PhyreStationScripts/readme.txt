[SCE CONFIDENTIAL DOCUMENT]
PhyreEngine(TM) Package 2.7.0
Copyright (C) 2010 Sony Computer Entertainment Inc.
All Rights Reserved.
 
PhyreStation Script directory
-----------------------------

This directory contains starter/example Lua scripts for use with 
PhyreStation. Some of the scripts contained here work in conjunction
with a workspace file found in the PhyreStation Workspace directory.

More details on Lua
-------------------
See also Lua at: http://www.lua.org
