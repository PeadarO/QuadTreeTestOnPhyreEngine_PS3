[SCE CONFIDENTIAL DOCUMENT]
PhyreEngine(TM) Package 2.7.0
Copyright (C) 2010 Sony Computer Entertainment Inc.
All Rights Reserved.
 
PhyreStation Workspace files
----------------------------

This directory provides a set of starter/example PhyreStation
Workspace project files.