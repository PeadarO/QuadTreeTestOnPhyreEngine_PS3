[SCE CONFIDENTIAL DOCUMENT]
PhyreEngine(TM) Package 2.7.0
Copyright (C) 2010 Sony Computer Entertainment Inc.
All Rights Reserved.
 
Overview
--------

PhyreStation is a GUI tool with which users can view and manipulate
art assets for use in development projects. The application is 
available on the Windows platform.

PhyreStation specifically operates on PhyreEngine(TM) databases and
objects, which can be stored in PhyreEngine(TM) database files or
imported from COLLADA(TM) files.

For more details, refer to the 'PhyreStation User's Guide' in the 
separate PhyreEngine(TM) documentation package for more information.

=====================================================================
=====================================================================

Dependencies
------------

PhyreStation requires Cg version 2.0 or above to be already installed.

=====================================================================
=====================================================================

Installation
------------

Currently, PhyreStation can be installed on Windows XP or Vista.

---------------------------------------------------------
Windows XP or Vista                                     |
---------------------------------------------------------

1. Install Cg support.

2. Install PhyreEngine(TM) as described in the 'PhyreEngine(TM)
   Programming Guide' found in the separate PhyreEngine(TM) 
   documentation package. This will unpack and copy all necessary
   PhyreStation binaries.

3. The following files should have been unpacked into the
   Tools\PhyreStation directory:

    Readme_e.txt                      - This document

    PhyreStation.exe                  - PhyreStation executable
    PhyreStationDll.dll               - PhyreStation library
                                        (PhyreEngine(TM))

    RDCoreGUIUtilsQt4R.dll            - PhyreStation library 
    RDCoreUtilsParameterStackQt4R.dll - PhyreStation library
    RDCoreUtilsQt4R.dll               - PhyreStation library 
    RDPkgAppInfoQt4R.dll              - PhyreStation library 
    RDPkgDnDTabWidgetsQt4R.dll        - PhyreStation library 
    RDPkgHelpViewerQt4R.dll           - PhyreStation library 
    RDPkgLoggerQt4R.dll               - PhyreStation library 
    RDPkgPreferenceManagerQt4R.dll    - PhyreStation library 
    RDPkgScriptLuaQt4R.dll            - PhyreStation library 
    RDPkgTraceMonitorQt4R.dll         - PhyreStation library 
    RDPkgXmlQt4R.dll                  - PhyreStation library 
    RDPkgNdlGraphQt4.dll              - PhyreStation library

    msvcp90.dll                - Microsoft run-time system library
    msvcr90.dll                - Microsoft run-time system library
    Qt3Support4.dll            - TrollTech Qt v4.3.x run-time library
    QtCore4.dll                - TrollTech Qt v4.3.x run-time library
    QtGui4.dll                 - TrollTech Qt v4.3.x run-time library
    QtNetwork4.dll             - TrollTech Qt v4.3.x run-time library
    QtOpenGL4.dll              - TrollTech Qt v4.3.x run-time library
    QtSql4.dll                 - TrollTech Qt v4.3.x run-time library
    QtSvg4.dll                 - TrollTech Qt v4.3.x run-time library
    QtXml4.dll                 - TrollTech Qt v4.3.x run-time library
    imageformats\qgif4.dll     - TrollTech Qt v4.3.x run-time library
    imageformats\qjpeg4.dll    - TrollTech Qt v4.3.x run-time library
    imageformats\qmng4.dll     - TrollTech Qt v4.3.x run-time library
    imageformats\qsvg4.dll     - TrollTech Qt v4.3.x run-time library
    imageformats\qtiff4.dll    - TrollTech Qt v4.3.x run-time library

    codecs\qjpcodecs4.dll      - TrollTech Qt v4.3.x run-time library

=====================================================================
=====================================================================

Specific Release Notes
----------------------

2.7.0
-----
Please be aware:
- PhyreStation now outputs to the script log file as well as the Log
  window PhyreEngine (TM) PrintF statements. Do not enclose any text
  within angle brackets (< >) as this will be removed from the text
  prior to output.
- Trying to scroll a lot of text in the command line window history
  pane or the Log window may stall the tool. This may also occur when
  the windows are resized. Use the 'Clear' option from the window's
  context menu to remove previous text.
- Typing an invalid IP address into DNet host edit box can stall 
  PhyreStation for a few minutes without any visible change in the 
  GUI.

The following are known problems:
Known issues
- The command Compress Render Data Source does not give the user any 
  information when it has succeeded but is not able to make any 
  further compression. To the user it looked like the command didn't  
  do anything.
- Change the attribute of an object property if the last reference 
  to another database to be internal to the object's database does
  not always update the database view properties link status
  correctly. Unloading the database and reloading will show the 
  correct status.
- Changing an PhyreEngine(TM)'s objects attribute which is a link
  to a resource in another database to either <empty> or reference
  to a resource internal to the object's database does not update
  the Workspace Explorer Database view. The object's database's
  linked databases are not updated. The same applies if you are
  creating a link to another database. The effected databases need
  to be unloaded, loaded and resolved to see the correct link 
  databases.
- When executing a script from the OS command line that is contained  
  within a workspace, that script and other associated scripts will not 
  be displayed the Workspace Explorer Scripts filter view. Opening the
  same workspace file from the GUI will show the associated scripts.
- The updating of other Graphs Editors to reflect changes made in a
  Graph Editor will not occur. To see the latest data changes the 
  Graph Editor needs to be closed and then reopened on the same
  subject.
- Changes applied in the User Preferences are sometimes not 
  persistent.
- Workspace Explorer tabs are sometimes not updated after executing a
  command.

General Release Notes
---------------------
When entering '\' characters in PhyreStation e.g. entering a file 
path, PhyreStation will replace the '\' character with the '/' 
character.