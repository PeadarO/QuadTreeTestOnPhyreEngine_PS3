[SCE CONFIDENTIAL DOCUMENT]
PhyreEngine(TM) Package 2.7.0
Copyright (C) 2010 Sony Computer Entertainment Inc.
All Rights Reserved.
 
PhyreStation picture icons to display in its GUI. They are a mixture
of sizes, normally 16x16 or 22x22. Any non-standard icon type image
should be put in the Images directory, not here.
