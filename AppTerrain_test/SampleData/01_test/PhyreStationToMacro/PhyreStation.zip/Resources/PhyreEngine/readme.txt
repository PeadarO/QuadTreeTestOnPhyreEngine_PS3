[SCE CONFIDENTIAL DOCUMENT]
PhyreEngine(TM) Package 2.7.0
Copyright (C) 2010 Sony Computer Entertainment Inc.
All Rights Reserved.
 
PhyreStation requires the following PhyreEngine(TM) database(s) to 
set itself up:
  - sphere.PSSG